//
//  ViewController.swift
//  ukulele_chords_mmm0155
//
//  Created by Mathias Morache on 4/1/20.
//  Copyright © 2020 Mathias Morache. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func aMajorButton(_ sender: UIButton) {
        
        switch sender.tag {
            case 0: drawAmajor()
            case 1: drawAminor()
        case 2: drawAmajor7()
        case 3: drawAminor7()
        case 4: drawAaug()
        case 5: drawAsharpMajor()
        case 6: drawAsharpMinor()
        case 7: drawAsharpMajorSeven()
        case 8: drawAsharpMinorSeven()
        case 9: drawAsharpAugmented()
        case 10: drawBmajor()
        case 11: drawBminor()
        case 12: drawBmajorSeven()
        case 13: drawBminorSeven()
        case 14: drawBaug()
        case 15: drawCmajor()
        case 16: drawCminor()
        case 17: drawCmajorSeven()
        case 18: drawCminorSeven()
        case 19: drawCaug()
        case 20: drawCsharpMajor()
        case 21: drawCsharpMinor()
        case 22: drawCsharpMajorSeven()
        case 23: drawCsharpMinorSeven()
        case 24: drawCsharpAug()
        case 25: drawDmajor()
        case 26: drawDminor()
        case 27: drawDmajorSeven()
        case 28: drawDminorSeven()
        case 29: drawDaug()
        case 30: drawDsharpMajor()
        case 31: drawDsharpMinor()
        case 32: drawDsharpMajorSeven()
        case 33: drawDsharpMinorSeven()
        case 34: drawDsharpAug()
        case 35: drawEmajor()
        case 36: drawEminor()
        case 37: drawEmajorSeven()
        case 38: drawEminorSeven()
        case 39: drawEaug()
        case 40: drawFmajor()
        case 41: drawFminor()
        case 42: drawFmajorSeven()
        case 43: drawFminorSeven()
        case 44: drawFaug()
        case 45: drawFsharpMajor()
        case 46: drawFsharpMinor()
        case 47: drawFsharpMajorSeven()
        case 48: drawFsharpMinorSeven()
        case 49: drawFsharpAug()
        case 50: drawGmajor()
        case 51: drawGminor()
        case 52: drawGmajorSeven()
        case 53: drawGminorSeven()
        case 54: drawGaug()
        case 55: drawGsharpMajor()
        case 56: drawGsharpMinor()
        case 57: drawGsharpMajorSeven()
        case 58: drawGsharpMinorSeven()
        case 59: drawGsharpAug()
            default: print("default")
        }
    }
    
    @IBOutlet weak var chordView: UIImageView!
    @IBOutlet weak var chordLabel: UILabel!
    @IBOutlet weak var stringOneLabel: UILabel!
    @IBOutlet weak var stringTwoLabel: UILabel!
    @IBOutlet weak var stringThreeLabel: UILabel!
    @IBOutlet weak var stringFourLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
      func drawAmajor() {
          // 1
          let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
          
          let img = renderer.image { ctx in
              
            ctx.cgContext.beginPath()

            ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
            ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
            ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
            ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
            ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
            ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
            ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
            ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
            ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
            ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
            ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
            ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
            ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
            ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
            // String 1 Fret 2
            ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))
            
            // String 2 Fret 1
            ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))
            
            // String 3 Open
            ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))
            
            // String 4 Open
            ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
            
              
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A major"
        stringOneLabel.text! = "2"
        stringTwoLabel.text! = "1"
        stringThreeLabel.text! = "0"
        stringFourLabel.text! = "0"
      }

    func drawAminor() {
        // tag 1
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          // String 1 Fret 2
          ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))
          
          // String 2 Open
          ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))
          
          // String 3 Open
          ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))
          
          // String 4 Open
          ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
          ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
          
            
            ctx.cgContext.setLineWidth(3)
            ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
            ctx.cgContext.setFillColor(UIColor.black.cgColor)
            // 3
            //ctx.cgContext.strokePath()
            ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
            ctx.cgContext.fillPath()
        }
        
      chordView.image = img
      chordLabel.text! = "A minor"
        stringOneLabel.text! = "2"
        stringTwoLabel.text! = "0"
        stringThreeLabel.text! = "0"
        stringFourLabel.text! = "0"
    }
    
    func drawAmajor7() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
            // String 1 Fret 1
            ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))
            
            // String 2 Fret 1
            ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))
            
            // String 3 Open
            ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))
            
            // String 4 Open
            ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
        
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            
        chordLabel.text! = "A major 7"
          stringOneLabel.text! = "1"
          stringTwoLabel.text! = "1"
          stringThreeLabel.text! = "0"
          stringFourLabel.text! = "0"
    }
    
    func drawAminor7() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
            // String 1 Open
            ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))
            
            // String 2 Open
            ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))
            
            
            // String 3 Open
            ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))
            
            // String 4 Open
            ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A minor 7"
          stringOneLabel.text! = "0"
          stringTwoLabel.text! = "0"
          stringThreeLabel.text! = "0"
          stringFourLabel.text! = "0"
    }
    
    func drawAaug() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
            
            // String 1 Fret 2
            ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))
            
            // String 2 Fret 1
            ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))
            
            // String 3 Fret 1
            ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))
            
            // String 4 Fret 4
            ctx.cgContext.move(to: CGPoint(x: 182, y: 180))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 180), control: CGPoint(x: 190, y: 195))
            ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 180), control: CGPoint(x: 190, y: 165))
            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A augmented"
          stringOneLabel.text! = "2"
          stringTwoLabel.text! = "1"
          stringThreeLabel.text! = "1"
          stringFourLabel.text! = "4"
    }


    func drawAsharpMajor() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
        
        // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A# major"
          stringOneLabel.text! = "3"
          stringTwoLabel.text! = "2"
          stringThreeLabel.text! = "1"
          stringFourLabel.text! = "1"
    }

    func drawAsharpMinor() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
        
        // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A# minor"
          stringOneLabel.text! = "3"
          stringTwoLabel.text! = "1"
          stringThreeLabel.text! = "1"
          stringFourLabel.text! = "1"
    }
    

    func drawAsharpMajorSeven() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
        
        // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))

            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A# major 7"
          stringOneLabel.text! = "3"
          stringTwoLabel.text! = "2"
          stringThreeLabel.text! = "1"
          stringFourLabel.text! = "0"
    }


    func drawAsharpMinorSeven() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
        
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))


    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A# minor 7"
          stringOneLabel.text! = "1"
          stringTwoLabel.text! = "1"
          stringThreeLabel.text! = "1"
          stringFourLabel.text! = "1"
    }
    
    func drawAsharpAugmented() {
        
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
        
        let img = renderer.image { ctx in
            
          ctx.cgContext.beginPath()

          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
          ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
          
          ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
          ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
          ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
            
        
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))


    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))


    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

            
              ctx.cgContext.setLineWidth(3)
              ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
              ctx.cgContext.setFillColor(UIColor.black.cgColor)
              // 3
              //ctx.cgContext.strokePath()
              ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
              ctx.cgContext.fillPath()
          }
          
        chordView.image = img
        chordLabel.text! = "A# augmented"
          stringOneLabel.text! = "3"
          stringTwoLabel.text! = "2"
          stringThreeLabel.text! = "2"
          stringFourLabel.text! = "1"
    }
    
    
        func drawBmajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 2, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 180), control: CGPoint(x: 10, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 180), control: CGPoint(x: 10, y: 165))


    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))


        // String 3 Fret 2
        ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "B major"
              stringOneLabel.text! = "4"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "2"
        }



         func drawBminor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 2, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 180), control: CGPoint(x: 10, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 180), control: CGPoint(x: 10, y: 165))



    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))


        // String 3 Fret 2
        ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "B minor"
              stringOneLabel.text! = "4"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "2"
        }


        func drawBmajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 2, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 180), control: CGPoint(x: 10, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 180), control: CGPoint(x: 10, y: 165))


    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))


        // String 3 Fret 2
        ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "B major 7"
              stringOneLabel.text! = "4"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "1"
        }


         func drawBminorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))



    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))


        // String 3 Fret 2
        ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
        ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "B minor 7"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "2"
        }






          func drawBaug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 2, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 180), control: CGPoint(x: 10, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 180), control: CGPoint(x: 10, y: 165))



    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))


    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "B augmented"
              stringOneLabel.text! = "4"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "2"
        }



        func drawCmajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))


    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C major"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "3"
        }





        func drawCminor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))


    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))


    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C minor"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "3"
        }









        func drawCmajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))


    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C major 7"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "2"
        }



         func drawCminorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))


    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))


    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C minor 7"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "2"
        }



         func drawCaug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))


    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C augmented"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "3"
        }

        func drawCsharpMajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 182, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 180), control: CGPoint(x: 190, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 180), control: CGPoint(x: 190, y: 165))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C# major"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "4"
        }



        func drawCsharpMinor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))



                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C# minor"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "X"
        }



        func drawCsharpMajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C# major 7"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "3"
        }




        func drawCsharpMinorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C# minor 7"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "1"
        }




        func drawCsharpAug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "C# augmented"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "0"
        }

        func drawDmajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D major"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "0"
        }


        func drawDminor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D minor"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "0"
        }



        func drawDmajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 182, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 180), control: CGPoint(x: 190, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 180), control: CGPoint(x: 190, y: 165))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D major 7"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "4"
        }





         func drawDminorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D minor 7"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "3"
        }




        func drawDaug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D augmented"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "1"
        }
    
    

        func drawDsharpMajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D# major"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "1"
        }



        func drawDsharpMinor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D# minor"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "1"
        }



        func drawDsharpMajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 5
    ctx.cgContext.move(to: CGPoint(x: 182, y: 220))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 220), control: CGPoint(x: 190, y: 235))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 220), control: CGPoint(x: 190, y: 205))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D# major 7"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "5"
        }




        func drawDsharpMinorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 182, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 180), control: CGPoint(x: 190, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 180), control: CGPoint(x: 190, y: 165))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D# minor 7"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "4"
        }





        func drawDsharpAug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "D# aug"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "2"
        }
    
    

        func drawEmajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 62, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 180), control: CGPoint(x: 70, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 180), control: CGPoint(x: 70, y: 165))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "E major"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "4"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "2"
        }







        func drawEminor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 62, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 180), control: CGPoint(x: 70, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 180), control: CGPoint(x: 70, y: 165))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "E minor"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "4"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "2"
        }





         func drawEmajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "E major 7"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "2"
        }




        func drawEminorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "E minor 7"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "2"
        }






        func drawEaug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))

                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "E augmented"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "3"
        }
    
    
    

        func drawFmajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F major"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "0"
        }





        func drawFminor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F minor"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "3"
        }




        func drawFmajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 62, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 180), control: CGPoint(x: 70, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 180), control: CGPoint(x: 70, y: 165))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F major 7"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "4"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "3"
        }


        func drawFminorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F minor 7"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "3"
        }



        func drawFaug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F augmented"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "0"
        }


    


        func drawFsharpMajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F# major"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "1"
        }




        func drawFsharpMinor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 62, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 60), control: CGPoint(x: 70, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 60), control: CGPoint(x: 70, y:45))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Open
    ctx.cgContext.move(to: CGPoint(x: 182, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 20), control: CGPoint(x: 190, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 20), control: CGPoint(x: 190, y:5))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F# minor"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "1"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "0"
        }






        func drawFsharpMajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 5
    ctx.cgContext.move(to: CGPoint(x: 62, y: 220))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 220), control: CGPoint(x: 70, y: 235))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 220), control: CGPoint(x: 70, y: 205))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 182, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 180), control: CGPoint(x: 190, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 180), control: CGPoint(x: 190, y: 165))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F# major 7"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "5"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "4"
        }





        func drawFsharpMinorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 2, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 100), control: CGPoint(x: 10, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 100), control: CGPoint(x: 10, y:85))

    // String 2 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 62, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 180), control: CGPoint(x: 70, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 180), control: CGPoint(x: 70, y: 165))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 182, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 180), control: CGPoint(x: 190, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 180), control: CGPoint(x: 190, y: 165))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F# minor 7"
              stringOneLabel.text! = "2"
              stringTwoLabel.text! = "4"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "4"
        }




        func drawFsharpAug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 2, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 140), control: CGPoint(x: 10, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 140), control: CGPoint(x: 10, y: 125))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "F# augmented"
              stringOneLabel.text! = "3"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "1"
        }

    

        func drawGmajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G major"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "2"
        }




        func drawGminor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G minor"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "1"
        }





        func drawGmajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G major 7"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "2"
        }





        func drawGminorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 62, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 100), control: CGPoint(x: 70, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 100), control: CGPoint(x: 70, y:85))

    // String 3 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 122, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 60), control: CGPoint(x: 130, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 60), control: CGPoint(x: 130, y:45))

    // String 4 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 182, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 60), control: CGPoint(x: 190, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 60), control: CGPoint(x: 190, y:45))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G minor 7"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "2"
              stringThreeLabel.text! = "1"
              stringFourLabel.text! = "1"
        }




        func drawGaug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Open
    ctx.cgContext.move(to: CGPoint(x: 2, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 20), control: CGPoint(x: 10, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 20), control: CGPoint(x: 10, y:5))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G augmented"
              stringOneLabel.text! = "0"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "2"
        }

    

        func drawGsharpMajor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 5
    ctx.cgContext.move(to: CGPoint(x: 2, y: 220))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 220), control: CGPoint(x: 10, y: 235))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 220), control: CGPoint(x: 10, y: 205))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 122, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 180), control: CGPoint(x: 130, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 180), control: CGPoint(x: 130, y: 165))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G# major"
              stringOneLabel.text! = "5"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "4"
              stringFourLabel.text! = "3"
        }




        func drawGsharpMinor() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 2, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 180), control: CGPoint(x: 10, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 180), control: CGPoint(x: 10, y: 165))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 4
    ctx.cgContext.move(to: CGPoint(x: 122, y: 180))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 180), control: CGPoint(x: 130, y: 195))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 180), control: CGPoint(x: 130, y: 165))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G# minor"
              stringOneLabel.text! = "4"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "4"
              stringFourLabel.text! = "2"
        }





        func drawGsharpMajorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 122, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 140), control: CGPoint(x: 130, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 140), control: CGPoint(x: 130, y: 125))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G# major 7"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "3"
              stringFourLabel.text! = "3"
        }




        func drawGsharpMinorSeven() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 62, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 140), control: CGPoint(x: 70, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 140), control: CGPoint(x: 70, y: 125))

    // String 3 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 122, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 100), control: CGPoint(x: 130, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 100), control: CGPoint(x: 130, y:85))

    // String 4 Fret 2
    ctx.cgContext.move(to: CGPoint(x: 182, y: 100))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 100), control: CGPoint(x: 190, y:115))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 100), control: CGPoint(x: 190, y:85))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G# minor 7"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "3"
              stringThreeLabel.text! = "2"
              stringFourLabel.text! = "2"
        }





        func drawGsharpAug() {
            
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 200, height: 250))
            
            let img = renderer.image { ctx in
                
              ctx.cgContext.beginPath()

              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 80))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 80))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 120))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 120))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 160))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 160))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 200))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 200))
              ctx.cgContext.move(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
              
              ctx.cgContext.move(to: CGPoint(x: 10, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 10, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 70, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 70, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 130, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 130, y: 240))
              ctx.cgContext.move(to: CGPoint(x: 190, y: 40))
              ctx.cgContext.addLine(to: CGPoint(x: 190, y: 240))
                
            
    // String 1 Fret 1
    ctx.cgContext.move(to: CGPoint(x: 2, y: 60))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 18, y: 60), control: CGPoint(x: 10, y:75))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 2, y: 60), control: CGPoint(x: 10, y:45))

    // String 2 Open
    ctx.cgContext.move(to: CGPoint(x: 62, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 78, y: 20), control: CGPoint(x: 70, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 62, y: 20), control: CGPoint(x: 70, y:5))

    // String 3 Open
    ctx.cgContext.move(to: CGPoint(x: 122, y: 20))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 138, y: 20), control: CGPoint(x: 130, y:35))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 122, y: 20), control: CGPoint(x: 130, y:5))

    // String 4 Fret 3
    ctx.cgContext.move(to: CGPoint(x: 182, y: 140))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 198, y: 140), control: CGPoint(x: 190, y: 155))
    ctx.cgContext.addQuadCurve(to: CGPoint(x: 182, y: 140), control: CGPoint(x: 190, y: 125))
                
                  ctx.cgContext.setLineWidth(3)
                  ctx.cgContext.setStrokeColor(UIColor.black.cgColor)
                  ctx.cgContext.setFillColor(UIColor.black.cgColor)
                  // 3
                  //ctx.cgContext.strokePath()
                  ctx.cgContext.drawPath(using: CGPathDrawingMode.eoFillStroke)
                  ctx.cgContext.fillPath()
              }
              
            chordView.image = img
            chordLabel.text! = "G# augmented"
              stringOneLabel.text! = "1"
              stringTwoLabel.text! = "0"
              stringThreeLabel.text! = "0"
              stringFourLabel.text! = "3"
        }


    
}

